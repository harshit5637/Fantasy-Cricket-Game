from setuptools import setup
setup(name='evaluation',
      version='1.0',
description='A package to Calculate the Scores of the Teams.',
url='#',
      author='Praveen',
      license='AUH',
      packages=['evaluation'],
zip_safe=False)
